# mlxcli
Interact with MLX models from the CLI. 
